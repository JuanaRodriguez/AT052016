=begin	
Administrator@AT01PJUARO001 MINGW64 /d/Test_folder/AT052016/Juana/practiceSession7 (master)
$ ruby practice7_1_2.rb
The first element is: 23	
=end
def first_element	
	array =[23,3,232]	
	puts  "The first element is: #{array.first}"
end

first_element