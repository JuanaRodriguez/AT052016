=begin
Administrator@AT01PJUARO001 MINGW64 /d/Test_folder/AT052016/Juana/practiceSession7 (master)
$ ruby practice7_1_3.rb
The last element is: 3	
=end
def last_element	
	array =[1,2,3]	
	puts  "The last element is: #{array.last}"
end

last_element